@echo off
set DIR=%~dp0
java -jar "%DIR%pasta-gui-1.4.4.jar" %*
