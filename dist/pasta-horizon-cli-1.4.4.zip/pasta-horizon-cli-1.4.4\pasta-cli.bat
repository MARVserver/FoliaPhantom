@echo off
set DIR=%~dp0
java -jar "%DIR%pasta-cli-1.4.4.jar" %*
