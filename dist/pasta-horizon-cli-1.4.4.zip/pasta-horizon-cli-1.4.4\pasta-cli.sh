#!/usr/bin/env sh
DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
java -jar "$DIR/pasta-cli-1.4.4.jar" "$@"
