#!/usr/bin/env sh
DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
java -jar "$DIR/pasta-gui-1.4.4.jar" "$@"
